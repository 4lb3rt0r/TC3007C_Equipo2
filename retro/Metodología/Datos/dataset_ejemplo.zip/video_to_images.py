import cv2 as cv
import os

# Cargamos el clasificador pre-entrenado de rostros
haar_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Variable que guarda el nombre del usuario
name = input("Ingrese el nombre de la persona a capturar el rostro: ")

# Inicializamos la captura de video de una grabación
video_path = r'C:\Users\alber\Desktop\Alberto\Reto IA\OpenCV\Face Recognition\data\input\Luisito Comunica\video_input.mp4'

# Creamos un directorio para guardar las capturas guardadas
output_directory = r'C:\Users\alber\Desktop\Alberto\Reto IA\OpenCV\Face Recognition\data\train'

output_directory = os.path.join(output_directory, name)

# Si no existe la ruta de salida
if not os.path.exists(output_directory):
    # Creamos la ruta
    os.makedirs(output_directory)

# Cargamos la captura de video de OpenCV
cap = cv.VideoCapture(video_path)
# Contador para capturar multiples frames por cada rostro detectado
image_count = 0
# Contador de imágenes guardadas
stored_images = 0

# Mientras el video no termine:
while True:
    # Leemos un frame de la captura de video
    ret, frame = cap.read()

    if not ret:
        break

    # Convertimos el frame a escala de grises para reconocimiento facial
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    # Detectamos posibles rostros en el frame
    faces = haar_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        if image_count % 10 == 0:
            # Dibujamos un rectángulo alrededor del rostro detectado
            cv.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            # Extraemos la captura del rostro
            face_image = frame[y:y+h, x:x+w]
            # Incrementamos el contador de imágenes guardadas
            stored_images += 1
            # Establecemos la ruta de salida
            image_filename = os.path.join(output_directory, f'captured_image_{stored_images}.png')
            cv.imwrite(image_filename, face_image)
        
        image_count += 1

# Cerramos las ventanas
cap.release()
cv.destroyAllWindows()

print("Imágenes guardadas: ", stored_images)